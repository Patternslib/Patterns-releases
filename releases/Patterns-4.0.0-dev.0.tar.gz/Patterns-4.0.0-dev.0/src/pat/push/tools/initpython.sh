#!/bin/sh
virtualenv .
./bin/pip install pika

