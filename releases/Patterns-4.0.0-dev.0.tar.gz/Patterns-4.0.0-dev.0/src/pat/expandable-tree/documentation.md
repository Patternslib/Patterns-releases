## Description

Expandable trees are typically used in applications that need to outputs
large amounts of hierarchically organised data.

## Documentation

Expandable tree has nog configurable options.