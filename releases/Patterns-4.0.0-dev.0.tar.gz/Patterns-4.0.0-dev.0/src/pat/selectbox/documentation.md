## Description

the __selectbox__ pattern adds ``data-option`` and ``data-option-value`` attributes on the parent element.
If the parent element is not a ``<label>`` it wrapts itself within a ``<span>`` element.

