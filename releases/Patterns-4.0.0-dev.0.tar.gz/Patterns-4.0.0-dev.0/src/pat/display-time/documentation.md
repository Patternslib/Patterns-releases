## Description

A pattern that makes dates easier to read.

## Documentation

