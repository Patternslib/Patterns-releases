jquery.form will be in ../3rdparty/ once we don't have the submodule anymore
