# Roadmap

Rough roadmap for features and changes that we intend to add.

Please don't interpret this roadmap as anything but a note and memory aide.
It doesn't represent a promise or commitment of any kind.

-   new carousel based on slick
-   new tooltip pattern
-   Better support for drag and drop
